<h2>#Two Wheeler Showroom Management System (tsmgmt)</h2><br>

Demo URL - http://syntegows.com/tsmgmt/<br>
Username - admin@admin.com<br>
Password - admin<br>
<br>

<h4>Installation Guide</h4>
Step -> 1<br>
	>> Create Database Name will be(Ex. tsmgmt)<br><br>
Step -> 2<br>
	>> config/PDO.php file open<br>
	>> Add Database Connection Detail<br>
	
![alt text](https://github.com/cgvaghela/tsmgmt/blob/master/config-PDO.png)<br>
<br>

Run ex. http://localhost/tsmgmt/