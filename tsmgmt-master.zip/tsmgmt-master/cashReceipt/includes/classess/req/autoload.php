<?php
/*  ---------------------------------------------------------------------------
 * 	@package	: Autoload : Including Required Files
 *	@author 	: The Creatix
 *	@version	: 1.0
 *	@link		: http://www.TheCreatix.com
 *	@copyright	: Copyright (c) 2015, http://www.TheCreatix.com
 *	--------------------------------------------------------------------------- */

require('fpdf/tfpdf.php');

require('rotation/rotation.php');

?>